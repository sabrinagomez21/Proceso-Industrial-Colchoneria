﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    public class Permisos
    {
        public static string IdRol;
        public static int IdUser;
        public static Int16 btnimprimir;
        public static Int16 btnnuevo;
        public static Int16 btnirUltimo;
        public static Int16 btnirPrimiero;
        public static Int16 btnanterior;
        public static Int16 btnsiguiente;
        public static Int16 btneditar;
        public static Int16 btncancelar;
        public static Int16 btnrefrescar;
        public static Int16 btnbuscar;
        public static Int16 btneliminar;
        public static Int16 btnguardar;
        

        
    }
}
