﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// esta clase contiene las validaciones
namespace WindowsFormsControlLibrary1
{
   public class clasnegocio : clasdatos
    {

      public void funconsultarRegistros(String tabla,String instruccion,String proceso,DataGridView gridDatos)
        {
            clasdatos.funobtenerRegistros(tabla,instruccion,proceso,gridDatos);
        }
     
       Array textBoxArray = new TextBox[10];
       #region asignar objetos GENERADOR DE INSERT
       public void AsignarObjetos(string snomtabla, Boolean binsertar, TextBox textBoxArray)
      {
          if(binsertar==true)
          {
              string query;
              string scadena = "INSERT INTO";
              string sparentizq = "(";
              string sparentder = ")";
              string scoma = ",";
              string scomsim = "'";
              string spuntocoma = ";";
              string svalues = "values";
              string saux = "";
              query = scadena + snomtabla + sparentizq;
              for(int x=0; x < 10; x++)
              {
                  var txtbox = new TextBox();
                  txtbox.Tag = saux.ToString();
                  query = query + saux + scoma;
              }
              char[] ccoma = {','};
              query = query.TrimEnd(ccoma);
              query = query + sparentder + svalues + sparentizq;
              for (int x = 0; x < 10; x++)
              {
                  var txtbox = new TextBox();
                  txtbox.Text = saux.ToString();
                  query = query + scomsim + saux + scomsim + scoma;
              }
              query = query.TrimEnd(ccoma);
              query = query + sparentizq + spuntocoma;
          }
      }
#endregion


       #region editar objetos GENERADOR UPDATE
       public void EditarObjetos(string snomtabla, Boolean beditar, TextBox textBoxArray, string sparam, string scamp) 
      {
          if(beditar==true)
          {
          string query;
          string scadena = "UPDATE";
          string sset = "SET";
          string swhere = "WHERE";
          string scomsim = "'";
          string scoma = ",";
          string sigual = "=";
          string spuntocoma = ";";
          string saux = "";
          string saux2 = "";
          query = scadena + snomtabla + sset;
          for (int x = 0; x < 10; x++)
          {
              var txtbox = new TextBox();
              txtbox.Tag = saux.ToString();
              txtbox.Text = saux2.ToString();
              query = query + saux + sigual + scomsim + saux2 + scomsim +scoma;
          }
          char[] ccoma = { ',' };
          query = query.TrimEnd(ccoma);
          query = query + swhere + scamp + sigual + scomsim + sparam + scomsim + spuntocoma;
          }
      }
       #endregion

       #region eliminar objetos GENERADOR DE UPDATE PARA DESACTIVAR CAMPOS
       public void EliminarObjetos(string snomtabla, Boolean beliminar, string sparam, string scamp)
      {
          if(beliminar==true)
          {
          string query;
          string scadena = "UPDATE";
          string sset = "SET";
          string sestado = "vestado";
          string sinactivo = "INACTIVO";
          string swhere = "WHERE";
          string scomsim = "'";
          string scoma = ",";
          string sigual = "=";
          string spuntocoma = ";";

          query = scadena + snomtabla + sset + sestado + sigual + sinactivo + swhere + scamp + sigual + scomsim + sparam + scomsim + spuntocoma;
          }
      }
       #endregion 


    }
}
