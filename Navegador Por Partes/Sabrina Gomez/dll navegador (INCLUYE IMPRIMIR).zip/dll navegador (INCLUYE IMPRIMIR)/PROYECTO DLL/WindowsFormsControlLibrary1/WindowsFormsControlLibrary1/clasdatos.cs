﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using MySql.Data;
using System.Data;


namespace WindowsFormsControlLibrary1
{
    public class clasdatos: clasconexion
    {
        private static MySqlCommand mySqlComando;
        private static MySqlDataAdapter mySqlDAdAdaptador;


        //INSERTAR, MODIFICAR, ELIMINAR
        #region INSERTAR,MODIFICAR,ELIMINAR
        public static int funinsertarModificarEliminar(String tabla,clasentidad instruccion,String proceso)
        {
            int iValorRetorno = 0;
            try
            {
                using (clasconexion.funobtenerConexion())
                {
                    mySqlComando = new MySqlCommand(string.Format(instruccion.squery), clasconexion.funobtenerConexion());
                    iValorRetorno = mySqlComando.ExecuteNonQuery();
                    clasconexion.funobtenerConexion().Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return iValorRetorno;
        }
        #endregion
        #region Llenar Tabla
        public static DataTable funobtenerRegistros(string tabla, String instruccion, String proceso,DataGridView griddatos)
        {
            DataTable dtRegistros = new DataTable();
            try
            {
                mySqlComando = new MySqlCommand(string.Format(instruccion),clasconexion.funobtenerConexion()
                 );
                mySqlDAdAdaptador = new MySqlDataAdapter();
                mySqlDAdAdaptador.SelectCommand = mySqlComando;
                mySqlDAdAdaptador.Fill(dtRegistros);
                griddatos.DataSource = dtRegistros;
                clasconexion.funobtenerConexion().Close();

            }
            catch (Exception Ex)
            {
                MessageBox.Show("No es posible obtener el registro", "Error al Realizar la Consulta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            return dtRegistros;
        }

        #endregion
       
        //RECORRER DATAGRID
        public void funirPrimero(DataGridView grdtabla) {
            
           
        }
        public void funirUltimo(DataGridView grdtabla){

        }
        public void funirAnterior(DataGridView grdtabla)
        {


        }
        public void funirSiguiente(DataGridView grdtabla)
        {


        }

    }
}
