﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsControlLibrary1
{
    public partial class ComponenteNavegador: UserControl
    {
        public ComponenteNavegador()
        {
            InitializeComponent();
        }
        
        private void btnnuevo_Click(object sender, EventArgs e)
        {
           
            funactivarTextbox(textBox1);
            funactivarTextbox(textBox2);
            funactivarTextbox(textBox3);
            funactivarCombobox(comboBox1);
            funactivarCombobox(comboBox2);

          /*los textbox array se declararán de esta forma
           */
            TextBox[] array = {/*aquí deberá colocar los nombres de los textbox utilizados separados por comas, si utilizó otro tipo de componente deberá de trasladar esa información a un textbox y colocarlo aqui.*/};
            
            
            
        
            
        }
        public funImprimir()
		  {
		    OpenFileDialog dialogo = new OpenFileDialog();
            dialogo.ShowDialog();
            if (dialogo.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = dialogo.FileName.ToString();
                Process printjob = new Process();
                printjob.StartInfo.FileName = textBox1.Text;
                printjob.StartInfo.UseShellExecute = true;
                printjob.StartInfo.CreateNoWindow = true;
                printjob.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                printjob.StartInfo.Verb = "print";
                printjob.Start();

            }
		
		
		
		}
        private void btnimprimir_Click(object sender, EventArgs e)
        {
            funImprimir();
        }

        public void btneditar_Click(object sender, EventArgs e)
        {
            
        }

        public void btneliminar_Click(object sender, EventArgs e)
        {
           
        }

        public void btnbuscar_Click(object sender, EventArgs e)
        {
          
        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
           
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            //fundesactivarBoton(btnimprimir);
            fundesactivarBoton(btnirPrimero);
            fundesactivarBoton(btnirUltimo);
            fundesactivarBoton(btnanterior);
            fundesactivarBoton(btnsiguiente);
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("clientes", "SELECT nombre,apellido,direccion from cliente", "consulta",gridDatos);
        }
        #region ACTIVAR DESACTIVAR BOTONES POR PERMISOS
        public void funactivarBoton(Button boton) {boton.Enabled = true;}
        public void fundesactivarBoton(Button boton) { boton.Enabled = false; }
        
        #endregion
        
        #region NUEVO Y CANCELAR
        public void funactivarTextbox(TextBox tb) {   tb.Enabled = true;   }
        public void fundesactivarTextbox(TextBox tb) { tb.Enabled = false; }

        public void funactivarCombobox(ComboBox cmbbox) { cmbbox.Enabled = true; }
        public void fundesactivarCombobox(ComboBox cmbbox) { cmbbox.Enabled = false; }
        #endregion 

        public void funactualizarForm(System.Windows.Forms.DataGridView grdtabla,String tabla,String instruccion,String proceso,DataGridView griddatos)
        {
            try
            {
               // grdtabla.DataSource = new clasnegocio().funconsultarRegistros(tabla, instruccion, proceso, griddatos);
                grdtabla.Refresh();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            fundesactivarTextbox(textBox1);
            fundesactivarTextbox(textBox2);
            fundesactivarTextbox(textBox3);
            fundesactivarCombobox(comboBox1);
            fundesactivarCombobox(comboBox2);
        }
    }
}
