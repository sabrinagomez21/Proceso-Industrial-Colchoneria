﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace WindowsFormsControlLibrary1
{
    public class clasconexion
    {
        private static MySqlConnection conBD;
        public static MySqlConnection funobtenerConexion() {
            conBD = new MySqlConnection("server=127.0.0.1; database=EjemploCapas; Uid=root; pwd=;");
            conBD.Open();
            return conBD;
        }
    }
}
