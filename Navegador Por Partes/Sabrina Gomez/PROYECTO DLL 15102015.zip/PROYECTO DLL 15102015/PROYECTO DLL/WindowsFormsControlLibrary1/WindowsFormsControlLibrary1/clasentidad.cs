﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsControlLibrary1
{
   public  class clasentidad
    {
       public string squery { get; set;}

       public clasentidad() { 

       }
      
       //esta funcion es la que a partir del array genere el string       
       public clasentidad(String instruccion) {
           this.squery = instruccion;
       }
    }
}
