﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using MySql.Data;
using System.Data;
using System.Data.Odbc;


namespace WindowsFormsControlLibrary1
{
    public class clasdatos: clasconexion
    {
        private static OdbcCommand mySqlComando;
        private static OdbcDataAdapter mySqlDAdAdaptador;


        //INSERTAR, MODIFICAR, ELIMINAR
        #region INSERTAR,MODIFICAR,ELIMINAR
        public static int funinsertarModificarEliminar(String tabla,String instruccion,String proceso)
        {
            int iValorRetorno = 0;
            try
            {
                using (clasconexion.funobtenerConexion())
                {
                    mySqlComando = new OdbcCommand(string.Format(instruccion), clasconexion.funobtenerConexion());
                    iValorRetorno = mySqlComando.ExecuteNonQuery();
                    clasconexion.funobtenerConexion().Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return iValorRetorno;
        }
        #endregion
        #region Llenar Tabla
        public static DataTable funobtenerRegistros(string tabla, String instruccion, String proceso,DataGridView griddatos)
        {
            DataTable dtRegistros = new DataTable();
            try
            {
                mySqlComando = new OdbcCommand(string.Format(instruccion),clasconexion.funobtenerConexion()
                 );
                mySqlDAdAdaptador = new OdbcDataAdapter();
                mySqlDAdAdaptador.SelectCommand = mySqlComando;
                mySqlDAdAdaptador.Fill(dtRegistros);
                griddatos.DataSource = dtRegistros;
                clasconexion.funobtenerConexion().Close();

            }
            catch (Exception Ex)
            {
                MessageBox.Show("No es posible obtener el registro", "Error al Realizar la Consulta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            return dtRegistros;
        }

        #endregion
        #region "LLENAR COMBOBOX (REFRESCAR)"
        public static DataTable funobtenerRegistrosCombo(string value, String instruccion, String visualizar, ComboBox cmbox) { 
        DataTable dtRegistrosCombo = new DataTable();
        OdbcCommand cmdc = new OdbcCommand(instruccion, clasconexion.funobtenerConexion());
        DataTable dtDatos = new DataTable();
        OdbcDataAdapter mdaDatos = new OdbcDataAdapter(instruccion, clasconexion.funobtenerConexion());
        mdaDatos.Fill(dtDatos);
        cmbox.ValueMember = value;
        cmbox.DisplayMember = visualizar;
        cmbox.DataSource = dtDatos;
        clasconexion.funobtenerConexion().Close();



        return dtRegistrosCombo;
        }
        #endregion
        //RECORRER DATAGRID
        #region Navegacion
        public static int funirPrimero(DataGridView gridDatos)
        {
            if (gridDatos.Rows.Count > 1)
            {
                gridDatos.Rows[0].Selected = true;
                gridDatos.CurrentCell = gridDatos.Rows[0].Cells[0];

                return 0;
            }
            else
            {
                MessageBox.Show("NO HAY REGISTROS");
                return 0;
            }

        }
        public static int funirUltimo(DataGridView gridDatos)
        {
            if (gridDatos.Rows.Count > 1)
            {
                int max = gridDatos.Rows.Count - 2;
                gridDatos.Rows[max].Selected = true;
                gridDatos.CurrentCell = gridDatos.Rows[max].Cells[0];
                return 0;
            }
            else
            {
                MessageBox.Show("NO HAY REGISTROS");
                return 0;
            }
        }
        public static int funirAnterior(DataGridView gridDatos)
        {
            if (gridDatos.Rows.Count > 1)
            {
                int valor = gridDatos.CurrentCell.RowIndex;
                int max = gridDatos.Rows.Count - 2;
                valor = valor - 1;
                if (valor >= 0)
                {
                    gridDatos.Rows[valor].Selected = true;
                    gridDatos.CurrentCell = gridDatos.Rows[valor].Cells[0];
                }
                else { MessageBox.Show("PRIMER REGISTRO"); }
                return 0;
            }
            else
            {
                MessageBox.Show("NO HAY DATOS");
                return 0;
            }
        }
        public static int funirSiguiente(DataGridView gridDatos)
        {
            if (gridDatos.Rows.Count > 1)
            {
                int valor = gridDatos.CurrentCell.RowIndex;
                int max = gridDatos.Rows.Count - 2;
                valor = valor + 1;
                if (valor <= max)
                {
                    gridDatos.Rows[valor].Selected = true;
                    gridDatos.CurrentCell = gridDatos.Rows[valor].Cells[0];
                }
                else { MessageBox.Show("ULTIMO REGISTRO"); }
                return 0;
            }
            else
            {
                MessageBox.Show("NO HAY DATOS");
                return 0;
            }

        }
        #endregion
        
        
        

    }
}
