﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Navegador
{
    public partial class frmbuscar : Form
    {
        public frmbuscar()
        {
            InitializeComponent();
        }

        private void frmbuscar_Load(object sender, EventArgs e)
        {

        }
    }
}
