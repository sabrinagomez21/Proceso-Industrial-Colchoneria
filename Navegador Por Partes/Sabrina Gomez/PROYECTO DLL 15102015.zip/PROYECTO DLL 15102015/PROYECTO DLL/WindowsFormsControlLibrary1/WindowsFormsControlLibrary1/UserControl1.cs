﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsControlLibrary1
{

    public partial class ComponenteNavegador : UserControl
    {

        public ComponenteNavegador()
        {
            InitializeComponent();

        }



        public void btnnuevo_Click(object sender, EventArgs e)
        {

            //funactivarTextbox(textBox1);
            //  funactivarTextbox(textBox2);
            // funactivarTextbox(textBox3);
            // funactivarCombobox(comboBox1);
            // funactivarCombobox(comboBox2);

            /*los textbox array se declararán de esta forma
             */

            TextBox[] array = { };




        }
        #region IMPRIMIR
        public void funimprimir(TextBox tb)
        {
            OpenFileDialog dialogo = new OpenFileDialog();
            dialogo.ShowDialog();
            if (dialogo.ShowDialog() == DialogResult.OK)
            {
                tb.Text = dialogo.FileName.ToString();
                Process printjob = new Process();
                printjob.StartInfo.FileName = tb.Text;
                printjob.StartInfo.UseShellExecute = true;
                printjob.StartInfo.CreateNoWindow = true;
                printjob.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                printjob.StartInfo.Verb = "print";
                printjob.Start();

            }
        }
        #endregion

        public void btnimprimir_Click(object sender, EventArgs e)
        {

            funimprimir(textBox1);
        }

        public void btneditar_Click(object sender, EventArgs e)
        {
            TextBox[] arr = { textBox2, textBox3, textBox4 };
            //Array textBoxArray = new TextBox[10];
            clasnegocio cn = new clasnegocio();
            cn.EditarObjetos("CLIENTE", true, arr, "1", "IdCliente");
        }
        #region "ELIMINAR"
        public void funeliminarRegistro(string sTabla, string sParametro, string sCampo, string scampoEstado)
        {
            string tabla = sTabla;
            string estado = scampoEstado;
            Boolean permiso = true;
            string parametro = sParametro; //código de lo que desea eliminar
            string campo = sCampo;
            if (MessageBox.Show("Esta Seguro De Eliminar El Registro? ", "Eliminar",
                     MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                clasnegocio cn = new clasnegocio();
                cn.EliminarObjetos(tabla, permiso, parametro, campo, estado);

                MessageBox.Show("Registro Eliminado");
            }

        }
        #endregion
        public void btneliminar_Click(object sender, EventArgs e)
        {
            /*
             funeliminarRegistro(1,2,3,4);
             * 1) Nombre tabla a eliminar registro
             * 2) Código de llave primaria a eliminar
             * 3) Campo de llave primaria 
             * 4) Nombre del campo estado de la tabla
             */
            funeliminarRegistro("Cliente", "13", "IdCliente", "Estado");
        }




        public void btnbuscar_Click(object sender, EventArgs e)
        {
            Navegador.frmbuscar xbuscar = new Navegador.frmbuscar();
            xbuscar.Show();

        }

        public void btnguardar_Click(object sender, EventArgs e)
        {

        }

        public void UserControl1_Load(object sender, EventArgs e)
        {
        }
        #region ACTIVAR DESACTIVAR BOTONES POR PERMISOS
        public void funactivarBoton(Button boton) { boton.Enabled = true; }
        public void fundesactivarBoton(Button boton) { boton.Enabled = false; }

        #endregion

        #region NUEVO Y CANCELAR
        public void funactivarTextbox(TextBox tb) { tb.Enabled = true; }
        public void fundesactivarTextbox(TextBox tb) { tb.Enabled = false; }

        public void funactivarCombobox(ComboBox cmbbox) { cmbbox.Enabled = true; }
        public void fundesactivarCombobox(ComboBox cmbbox) { cmbbox.Enabled = false; }
        #endregion




        public void btncancelar_Click(object sender, EventArgs e)
        {
            //fundesactivarTextbox(textBox1);
            // fundesactivarTextbox(textBox2);
            // fundesactivarTextbox(textBox3);
            // fundesactivarCombobox(comboBox1);
            // fundesactivarCombobox(comboBox2);
        }




        public void btnirPrimero_Click(object sender, EventArgs e)
        {
            clasnegocio navnegocio = new clasnegocio();
            navnegocio.funPrimero(dataGridView1);

        }



        public void btnanterior_Click(object sender, EventArgs e)
        {
            clasnegocio navnegocio = new clasnegocio();
            navnegocio.funAnterior(dataGridView1);
        }

        public void btnsiguiente_Click(object sender, EventArgs e)
        {
            clasnegocio navnegocio = new clasnegocio();
            navnegocio.funSiguiente(dataGridView1);
        }



        public void btnirUltimo_Click(object sender, EventArgs e)
        {
            clasnegocio navnegocio = new clasnegocio();
            navnegocio.funUltimo(dataGridView1);
        }

        private void btnrefrescar_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            /*
             * Función: funconsultarRegistrosCombo
             Esta funcion envía como parámetros (1,2,3,4) :
             * 1) Nombre Campo Value combobox
             * 2) Query select a la BD
             * 3) Nombre Campo DisplayMember combobox
             * 4) Nombre del combobox
             */
            cnegocio.funconsultarRegistrosCombo("IdCliente", "SELECT IdCliente,nombre from cliente", "nombre", comboBox1);

            /*
             * Función: funconsultarRegistros
             Esta funcion envía como parámetros (1,2,3,4) :
             * 1) Nombre Tabla
             * 2) Query select a la BD
             * 3) Procedimiento que realiza (consulta)
             * 4) Nombre del datagridview
             */
            cnegocio.funconsultarRegistros("clientes", "SELECT nombre,apellido,direccion from cliente", "consulta", dataGridView1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clasconexion.funobtenerConexion();

            MessageBox.Show("Conexion exitosa :)");

        }
    }
}
