﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
// esta clase contiene las validaciones
namespace WindowsFormsControlLibrary1
{
   public class clasnegocio : clasdatos
    {
#region "LLENAR GRID (REFRESCAR)"  
      public void funconsultarRegistros(String tabla,String instruccion,String proceso,DataGridView gridDatos)
        {
            clasdatos.funobtenerRegistros(tabla,instruccion,proceso,gridDatos);
        }
#endregion 

      #region "LLENAR COMBO (REFRESCAR)"
      /*
        * valorcombo: campo que será el value del combo
        * visualizar: campo que será lo que visualizaremos en el combo
        */
      public void funconsultarRegistrosCombo(String valorcombo, String instruccion, String visualizar,ComboBox cbox)
      {
          clasdatos.funobtenerRegistrosCombo(valorcombo, instruccion, visualizar, cbox);
      }
      #endregion 

      Array textBoxArray = new TextBox[10];
       #region asignar objetos GENERADOR DE INSERT
       public void AsignarObjetos(string snomtabla, Boolean binsertar, TextBox textBoxArray)
      {
          if(binsertar==true)
          {
              string query;
              string scadena = "INSERT INTO";
              string sparentizq = "(";
              string sparentder = ")";
              string scoma = ",";
              string scomsim = "'";
              string spuntocoma = ";";
              string svalues = "values";
              string saux = "";
              query = scadena + snomtabla + sparentizq;
              for(int x=0; x < 10; x++)
              {
                  var txtbox = new TextBox();
                  txtbox.Tag = saux.ToString();
                  query = query + saux + scoma;
              }
              char[] ccoma = {','};
              query = query.TrimEnd(ccoma);
              query = query + sparentder + svalues + sparentizq;
              for (int x = 0; x < 10; x++)
              {
                  var txtbox = new TextBox();
                  txtbox.Text = saux.ToString();
                  query = query + scomsim + saux + scomsim + scoma;
              }
              query = query.TrimEnd(ccoma);
              query = query + sparentizq + spuntocoma;
          }
      }
#endregion


       #region editar objetos GENERADOR UPDATE
       public void EditarObjetos(string snomtabla, Boolean beditar, TextBox[] textBoxArray, string sparam, string scamp) 
      {
          if(beditar==true)
          {
          string query;
          string scadena = "UPDATE";
          string sset = "SET";
          string swhere = "WHERE";
          string scomsim = "'";
          string scoma = ",";
          string sigual = "=";
          string spuntocoma = ";";
          string saux = "";
          string saux2 = "";
          query = scadena + snomtabla + sset;
          for (int x = 0; x < 10; x++)
          {
              var txtbox = new TextBox();
              txtbox.Tag = saux.ToString();
              txtbox.Text = saux2.ToString();
              query = query + saux + sigual + scomsim + saux2 + scomsim +scoma;
          }
          char[] ccoma = { ',' };
          query = query.TrimEnd(ccoma);
          query = query + swhere + scamp + sigual + scomsim + sparam + scomsim + spuntocoma;
          }
      }
       #endregion

      

       #region "NAVEGACION DE DATOS"
       public void funPrimero(DataGridView gridDatos)
       {
           clasdatos.funirPrimero(gridDatos);
       }
       public void funUltimo(DataGridView gridDatos)
       {
           clasdatos.funirUltimo(gridDatos);
       }

       public void funAnterior(DataGridView gridDatos)
       {
           clasdatos.funirAnterior(gridDatos);
       }

       public void funSiguiente(DataGridView gridDatos)
       {
           clasdatos.funirSiguiente(gridDatos);
       }

       #endregion

       #region "ELIMINAR"
       public  void EliminarObjetos(string snomtabla, Boolean beliminar, string sparam, string scamp,string scampoEstado)
       {
           if (beliminar == true)
           {
               string squery;
               string scadena = "UPDATE ";
               string sset = "SET ";
               string sestado = scampoEstado;
               string sinactivo = "INACTIVO";
               string swhere = "WHERE ";
               string scomsim = "'";
               string sespacio = " ";
               string sigual = "= ";
               string spuntocoma = ";";


               squery = scadena + snomtabla + sespacio + sset + sestado + sigual + scomsim + sinactivo + scomsim + sespacio + swhere + scamp + sigual + scomsim + sparam + scomsim + spuntocoma;
               funinsertarModificarEliminar(snomtabla, squery, "eliminar");
               
               /*   using (clasconexion.funobtenerConexion())
               {
                   MySqlCommand cmd2 = new MySqlCommand(squery, clasconexion.funobtenerConexion());
                   MySqlDataReader MyReader;
                   MyReader = cmd2.ExecuteReader();
               }*/
               MessageBox.Show(squery);
           }
       }

       #endregion  
   }
}
