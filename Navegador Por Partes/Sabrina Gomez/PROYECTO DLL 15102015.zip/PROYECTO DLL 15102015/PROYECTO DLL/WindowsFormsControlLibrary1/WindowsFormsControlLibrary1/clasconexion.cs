﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Odbc;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsControlLibrary1
{
    public class clasconexion
    {
        public static OdbcConnection funobtenerConexion()
        {

            OdbcConnection cn;




            cn = new OdbcConnection("Driver={MySQL ODBC 5.3 ANSI Driver};server=localhost;uid=root;database=colchoneria;port=3306");
              cn.Open();

            MessageBox.Show("Connected");

            cn.Close();
            return cn;
        }
    }
}