﻿namespace RRHH
{
    partial class frmPRINCIPAL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dETALLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONTRATACIONESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rECLUTAMIENTODEPERSONALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sELECCIONDEPERSONALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONTRATADOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rELACIONESLABORALESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLANILLAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desarrolloOrganizacionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fODAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AllowMerge = false;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dETALLEToolStripMenuItem,
            this.cONTRATACIONESToolStripMenuItem,
            this.cONTRATADOSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.cONTRATACIONESToolStripMenuItem;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.ShowItemToolTips = true;
            this.menuStrip1.Size = new System.Drawing.Size(1301, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dETALLEToolStripMenuItem
            // 
            this.dETALLEToolStripMenuItem.Name = "dETALLEToolStripMenuItem";
            this.dETALLEToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.dETALLEToolStripMenuItem.Text = "DETALLE";
            this.dETALLEToolStripMenuItem.Click += new System.EventHandler(this.dETALLEToolStripMenuItem_Click);
            // 
            // cONTRATACIONESToolStripMenuItem
            // 
            this.cONTRATACIONESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rECLUTAMIENTODEPERSONALToolStripMenuItem,
            this.sELECCIONDEPERSONALToolStripMenuItem});
            this.cONTRATACIONESToolStripMenuItem.Name = "cONTRATACIONESToolStripMenuItem";
            this.cONTRATACIONESToolStripMenuItem.Size = new System.Drawing.Size(123, 20);
            this.cONTRATACIONESToolStripMenuItem.Text = "CONTRATACIONES";
            this.cONTRATACIONESToolStripMenuItem.Click += new System.EventHandler(this.cONTRATACIONESToolStripMenuItem_Click);
            // 
            // rECLUTAMIENTODEPERSONALToolStripMenuItem
            // 
            this.rECLUTAMIENTODEPERSONALToolStripMenuItem.Name = "rECLUTAMIENTODEPERSONALToolStripMenuItem";
            this.rECLUTAMIENTODEPERSONALToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.rECLUTAMIENTODEPERSONALToolStripMenuItem.Text = "RECLUTAMIENTO DE PERSONAL";
            this.rECLUTAMIENTODEPERSONALToolStripMenuItem.Click += new System.EventHandler(this.rECLUTAMIENTODEPERSONALToolStripMenuItem_Click);
            // 
            // sELECCIONDEPERSONALToolStripMenuItem
            // 
            this.sELECCIONDEPERSONALToolStripMenuItem.Name = "sELECCIONDEPERSONALToolStripMenuItem";
            this.sELECCIONDEPERSONALToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.sELECCIONDEPERSONALToolStripMenuItem.Text = "Ficha Empleado";
            this.sELECCIONDEPERSONALToolStripMenuItem.Click += new System.EventHandler(this.sELECCIONDEPERSONALToolStripMenuItem_Click);
            // 
            // cONTRATADOSToolStripMenuItem
            // 
            this.cONTRATADOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem,
            this.rELACIONESLABORALESToolStripMenuItem,
            this.pLANILLAToolStripMenuItem});
            this.cONTRATADOSToolStripMenuItem.Name = "cONTRATADOSToolStripMenuItem";
            this.cONTRATADOSToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.cONTRATADOSToolStripMenuItem.Text = "CONTRATADOS";
            // 
            // cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem
            // 
            this.cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem.Name = "cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem";
            this.cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem.Size = new System.Drawing.Size(323, 22);
            this.cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem.Text = "CAPACITACION Y DESARROLLO DE PERSONAL";
            this.cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem.Click += new System.EventHandler(this.cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem_Click_1);
            // 
            // rELACIONESLABORALESToolStripMenuItem
            // 
            this.rELACIONESLABORALESToolStripMenuItem.Name = "rELACIONESLABORALESToolStripMenuItem";
            this.rELACIONESLABORALESToolStripMenuItem.Size = new System.Drawing.Size(323, 22);
            this.rELACIONESLABORALESToolStripMenuItem.Text = "RELACIONES LABORALES";
            this.rELACIONESLABORALESToolStripMenuItem.Click += new System.EventHandler(this.rELACIONESLABORALESToolStripMenuItem_Click_1);
            // 
            // pLANILLAToolStripMenuItem
            // 
            this.pLANILLAToolStripMenuItem.Name = "pLANILLAToolStripMenuItem";
            this.pLANILLAToolStripMenuItem.Size = new System.Drawing.Size(323, 22);
            this.pLANILLAToolStripMenuItem.Text = "PLANILLA";
            this.pLANILLAToolStripMenuItem.Click += new System.EventHandler(this.pLANILLAToolStripMenuItem_Click_1);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage_1);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDeToolStripMenuItem,
            this.desarrolloOrganizacionalToolStripMenuItem,
            this.fODAToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 24);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1301, 24);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.MergeAction = System.Windows.Forms.MergeAction.Insert;
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.acercaDeToolStripMenuItem.Text = "Acerca de ";
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // desarrolloOrganizacionalToolStripMenuItem
            // 
            this.desarrolloOrganizacionalToolStripMenuItem.Name = "desarrolloOrganizacionalToolStripMenuItem";
            this.desarrolloOrganizacionalToolStripMenuItem.Size = new System.Drawing.Size(152, 20);
            this.desarrolloOrganizacionalToolStripMenuItem.Text = "Desarrollo organizacional";
            // 
            // fODAToolStripMenuItem
            // 
            this.fODAToolStripMenuItem.Name = "fODAToolStripMenuItem";
            this.fODAToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.fODAToolStripMenuItem.Text = "FODA";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.salirToolStripMenuItem.Text = "Salir";
            // 
            // frmPRINCIPAL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1301, 540);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPRINCIPAL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Recursos Humanos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPRINCIPAL_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem dETALLEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONTRATACIONESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rECLUTAMIENTODEPERSONALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sELECCIONDEPERSONALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONTRATADOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cAPACITACIONYDESARROLLODEPERSONALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rELACIONESLABORALESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pLANILLAToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocument1;
        public System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desarrolloOrganizacionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fODAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
    }
}